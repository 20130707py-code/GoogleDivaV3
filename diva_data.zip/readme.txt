【歌手名稱】Google Diva V3
【版本】Version 3.0 (正式版)
【聲音來源】Google 導覽音
【立繪設計】(在這裡填寫妳的名字或是製作者名字)
【使用聲碼器建議】Moresampler / TIPS
【類型】CV (單獨音)

【說明】
這是 Google Diva 的第三代版本，優化了 16-bit 音質，
並新增了全新的透明全身立繪！

【使用條款】
請遵守 Google 相關使用規範，請勿用於商業用途。